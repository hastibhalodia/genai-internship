# GenAI Internship

This repository contains task-wise work done during the GenAI internship.

## Structure

- `setup/`: Environment setup scripts and validation
- `notebooks/`: All task notebooks
- `src/`: Scripts and utilities
- `microcourses/`: Badges/screenshots of completed courses
- `docs/`: Notes and blog posts

## Pre-commit

Uses `black` and `ruff` for code formatting and linting.
