# Environment Setup

Steps taken to set up the environment.